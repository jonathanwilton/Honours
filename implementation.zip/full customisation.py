# full customisation
import torch
import pandas as pd
from classes import MyMethod

data = pd.read_csv('Nile.csv')["Nile"]
y = torch.Tensor(data).view(-1,1)
split = int(0.8*len(y))
train = y[:split]
test = y[split:]
#%%
g = MyMethod(dist = ['Normal','Laplace', 't5','Cauchy'], device = 
                 'cpu', m = 1000, num = 30, epochs = 300, N = 30, L = [0,1,2], 
                 D = [10,50], lag = [30,60], tol = [8,15,30], alphas = 
                 [0.5, 1/3, 0.05, 0.01], split = 0.8, acquisition = 'EI', 
                 iterations = 30, lr = 0.005, prediction_method = 'median')
# iterations is the number of iterations of BO to use, has a big effect on training time.

g.fit(train, metric = 'accuracy+uncertainty', surrogate = 'GP')
print('hyperparams learnt by BO: [NN depth, hidden layer width, lag, tol, skewed dist] =', g.params())
point, intervals, ind_points = g.predict(future = len(test), return_ind = True)
g.plot(point, intervals, test = test, probs = [0.5,0.67,0.95,0.99], plot_ind = True, ind_points = ind_points, legend = True, save_fig = False)
point_loss, (lower_loss, upper_loss) = g.loss(test, point, intervals, point_criterion = 'MASE', interval_criterion = 'scaled_pinball')
prob = g.prob_increase()
incr = g.expected_increase()

print('\nPoint predicitions MASE:', point_loss)
print('Lower prediction intervals scaled pinball loss:', lower_loss)
print('Upper prediction intervals scaled pinball loss:', upper_loss)
print('Probability of increase P(Y_{n+1} > y_n):', prob)
print('Expected increase E[Y_{n+1} - y_n]:', incr)
print('Observed increase y_{n+1} - y_n:', (test[0]-train[-1]).item())
